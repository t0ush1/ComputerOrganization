testpoint 1-9 为程序自动生成的随机样例
testpoint 0 为根据分析程序手动补充的数据
总体forward和stall的均分能分别达到85和95，且没有warning